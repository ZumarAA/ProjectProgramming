# this file will have the code to link the other three modules.
import loginUI
def main():
    loginUI.mainwindow()  # calls the loginUI to show login window

if __name__ == "__main__":
    main()

